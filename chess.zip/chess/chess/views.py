import json
from rest_framework.viewsets import ViewSet
from rest_framework.response import Response
from rest_framework import status
from chess.game import g


class ChessGameView(ViewSet):

    def list(self, request, *args, **kwargs):
        
        g.generate_board()
        g.print_board()
        return Response(
            {
                'msg': 'board createds',
            },
            status=status.HTTP_201_CREATED,
        )


class BoardView(ViewSet):
    def list(self, request, *args, **kwargs):
        board = json.dumps(
            g.board, default=lambda o: o.__dict__, sort_keys=True, indent=4
        )
        g.print_board()
        return Response({'board': json.loads(board)})


class MoveView(ViewSet):
    def list(self, request, *args, **kwargs):
        from_position = request.data['from_position']
        to_position = request.data['to_position']


        if g.validate_move(from_position, to_position):
            g.move(from_position, to_position)
            g.print_board()

            return Response(request.data, status=status.HTTP_200_OK)
        else:
            return Response({'msg': 'Not allowed move'})
