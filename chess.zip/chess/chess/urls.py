from django.urls import path
# from .views import ChessMovesView, ChessGameView, BoardView
from .views import  ChessGameView, BoardView, MoveView


urlpatterns = [
    path('board/', BoardView.as_view({'get':'list'})),
    path('start/', ChessGameView.as_view({'get':'list'})),
    path('move/', MoveView.as_view({'get': 'list'})),


    # path()
]